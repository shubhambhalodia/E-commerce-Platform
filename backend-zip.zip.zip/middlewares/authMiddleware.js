const jwt=require('jsonwebtoken');
const pool = require('../config/db');
const requireSignIn = async (req, res, next) => {
    try {
    console.log("in try");
      const decode = jwt.verify(
        req.headers.authorization,
        process.env.JWT_SECRET
      );
      console.log(decode+"decode");
      req.user = decode;
      next();
    } catch (error) {
      console.log(error);
    }
  };

    const isAdmin = async (req, res, next) => {
    try {

      const email = req.body.email;
      console.log(email);
      const user=await pool.query("SELECT * from users WHERE email=$1",[email]);
      console.log(user.rows[0]+"authhhhhh");
      if (user.rows[0].role !== 'admin') {
        return res.status(401).send({
          success: false,
          message: "UnAuthorized Access",
        });
      } else {
        next();
      }
    } catch (error) {
      console.log(error);
      res.status(401).send({
        success: false,
        error,
        message: "Error in admin middelware",
      });
    }
  };
  module.exports={requireSignIn,isAdmin};