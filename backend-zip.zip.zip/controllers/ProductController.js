const pool = require('../config/db');
const fs = require("fs");
const slugify = require("fs");

// Function to handle creating a new product
const createProduct = async (req, res) => {
  try {
    const { name, description, price, category, quantity, shipping } = req.fields;
    const { photo } = req.files;

    // Validation
    if (!name || !description || !price || !category || !quantity) {
      return res.status(500).send({ error: "All fields are required" });
    }

    // const slug = slugify(name);  
    let photoData = null;
    let photoContentType = null;

    if (photo) {
      photoData = fs.readFileSync(photo.path);
      photoContentType = photo.type;
    }

    const result = await pool.query(
      `INSERT INTO products (name, description, price, category, quantity, photo, photo_content_type, shipping, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW())
       RETURNING *`,
      [name, description, price, category, quantity, photoData, photoContentType, shipping]
    );

    res.status(201).send({
      success: true,
      message: "Product Created Successfully",
      product: result.rows[0],
    });
  } catch (error) {
    console.error("Error creating product:", error);
    res.status(500).send({
      success: false,
      error: error.message,
      message: "Error in creating product",
    });
  }
};

// Function to get all products
const getProductController = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, name, description, price, category, quantity, shipping, created_at, updated_at
       FROM products
       ORDER BY created_at DESC`
    );

    res.status(200).send({
      success: true,
      countTotal: result.rowCount,
      message: "All Products",
      products: result.rows,
    });
  } catch (error) {
    console.error("Error getting products:", error);
    res.status(500).send({
      success: false,
      error: error.message,
      message: "Error in getting products",
    });
  }
};

// Function to get a single product by slug
const getSingleProductController = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, name, description, price, category, quantity, shipping, created_at, updated_at
       FROM products
       WHERE id = $1`,
      [req.params.id]
    );

    if (result.rowCount === 0) {
      return res.status(404).send({
        success: false,
        message: "Product not found",
      });
    }

    res.status(200).send({
      success: true,
      message: "Single Product Fetched",
      product: result.rows[0],
    });
  } catch (error) {
    console.error("Error getting single product:", error);
    res.status(500).send({
      success: false,
      error: error.message,
      message: "Error while getting single product",
    });
  }
};

// Function to get product photo by product ID
const productPhotoController = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT photo, photo_content_type
       FROM products
       WHERE id = $1`,
      [req.params.id]
    );

    if (result.rowCount === 0 || !result.rows[0].photo) {
      return res.status(404).send({
        success: false,
        message: "Photo not found",
      });
    }

    res.set("Content-type", result.rows[0].photo_content_type);
    res.status(200).send(result.rows[0].photo);
  } catch (error) {
    console.error("Error getting product photo:", error);
    res.status(500).send({
      success: false,
      error: error.message,
      message: "Error while getting product photo",
    });
  }
};

// Function to delete a product by product ID
const deleteProductController = async (req, res) => {
  try {
    const result = await pool.query(
      `DELETE FROM products
       WHERE id = $1
       RETURNING *`,
      [req.params.id]
    );

    if (result.rowCount === 0) {
      return res.status(404).send({
        success: false,
        message: "Product not found",
      });
    }

    res.status(200).send({
      success: true,
      message: "Product Deleted Successfully",
    });
  } catch (error) {
    console.error("Error deleting product:", error);
    res.status(500).send({
      success: false,
      error: error.message,
      message: "Error while deleting product",
    });
  }
};

// Function to update a product by product ID
const updateProductController = async (req, res) => {
  try {
    const { name, description, price, category, quantity, shipping } = req.fields;
    const { photo } = req.files;

    // Validation
    if (!name || !description || !price || !category || !quantity) {
      return res.status(500).send({ error: "All fields are required" });
    }

    const slug = slugify(name);
    let photoData = null;
    let photoContentType = null;

    if (photo) {
      photoData = fs.readFileSync(photo.path);
      photoContentType = photo.type;
    }

    const result = await pool.query(
      `UPDATE products
       SET name = $1, description = $3, price = $4, category = $5, quantity = $6, photo = $7, photo_content_type = $8, shipping = $9, updated_at = NOW()
       WHERE id = $10
       RETURNING *`,
      [name, description, price, category, quantity, photoData, photoContentType, shipping, req.params.pid]
    );

    if (result.rowCount === 0) {
      return res.status(404).send({
        success: false,
        message: "Product not found",
      });
    }

    res.status(200).send({
      success: true,
      message: "Product Updated Successfully",
      product: result.rows[0],
    });
  } catch (error) {
    console.error("Error updating product:", error);
    res.status(500).send({
      success: false,
      error: error.message,
      message: "Error in updating product",
    });
  }
};

module.exports = {createProduct, getProductController, getSingleProductController, productPhotoController,deleteProductController, updateProductController,
};
