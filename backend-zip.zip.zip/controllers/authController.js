const pool=require('../config/db');
const {hashPassword,comparePassword}=require('../helpers/authHelper');
const jwt=require('jsonwebtoken');
exports.registerController=async(req,res)=>{
    try {
        const { name, email, password, phone, address , role} = req.body;
        //validations
        if (!name) {
          return res.send({ error: "Name is Required" });
        }
        if (!email) {
          return res.send({ message: "Email is Required" });
        }
        if (!password) {
          return res.send({ message: "Password is Required" });
        }
        if (!phone) {
          return res.send({ message: "Phone no is Required" });
        }
        if (!address) {
          return res.send({ message: "Address is Required" });
        }
        if (!role) {
          return res.send({ message: "role is Required" });
        }
        //check user
        const { rows:exisitingUser, rowCount} = await pool.query('SELECT * FROM users WHERE email=$1',[email]);
        
        //exisiting user
        if (exisitingUser && rowCount > 0) {
          return res.status(400).send({
            success: false,
            message: "Already Register please login",
          });
        }
        //register user
        const value = await hashPassword(password);
        //save
        const user = await pool.query("INSERT INTO users (name,email,password,phone,address,role) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *",
        [name,email,value,phone,address,role])
    
        res.status(201).send({
          success: true,
          message: "User Register Successfully",
          user:user.rows[0],
        });
      } catch (error) {
        console.log(error);
        res.status(500).send({
          success: false,
          message: "Errro in Registeration",
          error,
        });
      }
}

exports.loginController=async(req,res)=>{
  try{
    const {email,password}=req.body;
    if(!email || !password){
      res.status(404).send({
        success: false,
        messade: "Both email and password are required"
      })
    }
    const { rows:exisitingUser, rowCount} = await pool.query('SELECT * FROM users WHERE email=$1',[email]);
    if(!exisitingUser[0]){
      return res.status(404).send({
        success: false,
        message: "Email is not registerd",
      });
    }
    console.log(exisitingUser[0].password+"passssssssss");
    hashPass=exisitingUser[0].password
    const match = await comparePassword(password,hashPass);
    if (!match) {
      return res.status(200).send({
        success: false,
        message: "Invalid Password",
      });
    }
    const {name,phone,address,role}=exisitingUser[0];
    const token=await jwt.sign({email:email},process.env.JWT_SECRET,{expiresIn: "7d",});
    res.status(200).send({
      success: true,
      message: "login successfully",
      user: {
        name,email,password,phone,address,role
      },
      token,
    });
  }
  catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Errro in login",
      error,
    });
  }
}

exports.testController=async(req,res)=>{
  try{
    console.log("TestController");
  }
  catch(err){

  }
}
