const express=require('express');
const registerController = require('../controllers/authController');
const { isAdmin, requireSignIn } = require('../middlewares/authMiddleware');
const router=express.Router();
router.post('/register',registerController.registerController);
router.post('/login',registerController.loginController);
router.post('/test',requireSignIn,isAdmin,registerController.testController);
router.get('/user-auth',(req,res)=>{
    res.status(200).send({ok:true});
});
router.get('/admin-auth',(req,res)=>{
    res.status(200).send({ok:true});
});
module.exports=router;