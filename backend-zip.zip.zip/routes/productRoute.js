const express=require('express');
const {
  createProduct,
  deleteProductController,
  getProductController,
  getSingleProductController,
  productPhotoController,
  updateProductController,
} =require("../controllers/productController.js");
const formidable =require("express-formidable");

const router = express.Router();

//routes
router.post(
  "/create-product",
  formidable(),
  createProduct
);
//routes
router.put(
  "/update-product/:pid",
  formidable(),
  updateProductController
);

router.get("/get-product", getProductController);
router.get("/get-product/:slug", getSingleProductController);
router.get("/product-photo/:pid", productPhotoController);

router.delete("/product/:pid", deleteProductController);

module.exports = router;