import React from 'react'
import Layout from '../components/layout/Layout'

const Policy = () => {
  return (
    <Layout>
        
    <div>Policy</div>
    </Layout>
  )
}

export default Policy